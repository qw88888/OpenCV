#include "perf_precomp.hpp"
#ifdef _MSC_VER
# if _MSC_VER >= 1700
#  pragma warning(disable:4447) // Disable warning 'main' signature found without threading model
# endif
#endif

CV_PERF_TEST_MAIN(core)
