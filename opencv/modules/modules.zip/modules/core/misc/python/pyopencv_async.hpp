#ifdef HAVE_OPENCV_CORE

#include "opencv2/core/async.hpp"

CV_PY_TO_CLASS(AsyncArray);
CV_PY_FROM_CLASS(AsyncArray);

#endif
