// This file is auto-generated. Do not edit!

#include "opencv2/core/ocl.hpp"
#include "opencv2/core/ocl_genbase.hpp"
#include "opencv2/core/opencl/ocl_defs.hpp"

#ifdef HAVE_OPENCL

namespace cv
{
namespace ocl
{
namespace objdetect
{

extern struct cv::ocl::internal::ProgramEntry cascadedetect_oclsrc;
extern struct cv::ocl::internal::ProgramEntry objdetect_hog_oclsrc;

}}}
#endif
