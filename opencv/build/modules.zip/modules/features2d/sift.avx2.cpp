
#include "/home/qw/opencv-3.4.15/modules/features2d/src/precomp.hpp"
#include "/home/qw/opencv-3.4.15/modules/features2d/src/sift.simd.hpp"
