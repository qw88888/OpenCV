
#include "/home/qw/opencv-3.4.15/modules/core/test/test_precomp.hpp"
#include "/home/qw/opencv-3.4.15/modules/core/test/test_intrin512.simd.hpp"
