#define CV_CPU_SIMD_FILENAME "/home/qw/opencv-3.4.15/modules/core/src/split.simd.hpp"
#define CV_CPU_DISPATCH_MODES_ALL BASELINE

#undef CV_CPU_SIMD_FILENAME
