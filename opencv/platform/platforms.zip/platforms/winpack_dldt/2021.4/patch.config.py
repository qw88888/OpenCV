applyPatch('20210630-dldt-disable-unused-targets.patch')
applyPatch('20210630-dldt-pdb.patch')
applyPatch('20210630-dldt-disable-multidevice-autoplugin.patch')
applyPatch('20210630-dldt-vs-version.patch')
