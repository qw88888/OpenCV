os.environ['CI_BUILD_NUMBER'] = '2021.4.0-opencv_winpack_dldt'
